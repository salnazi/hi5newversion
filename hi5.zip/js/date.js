$(function() {	
	$(function() {
		$( "#dob" ).datepicker({
			changeMonth: true,
			changeYear: true
	});	 
});	