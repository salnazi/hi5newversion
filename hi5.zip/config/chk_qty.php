<?php
error_reporting(0);
$rp = cPurchase_BalanceQty($_POST['SearchProduct']);
echo $rp;
?>