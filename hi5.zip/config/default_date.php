<?php
    $timezone = "Asia/Calcutta";
    if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
    $india_date_time = date('d/m/Y H:i:s');
    $india_date = date('Y-m-d');
?>