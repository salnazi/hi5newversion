<?php
error_reporting(0);
$rp = $_POST['qty'] * $_POST['rate'];
echo $rp;
?>