<?php
//error_reporting(0);
$rp = $_POST['rate'] / $_POST['qty'];
echo $rp;
?>