<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Developer : </b> <?php echo _DEVELOPER; ?> | <b>Email : </b> : <?php echo _DEVELOPER_EMAIL; ?>
    </div>
    <strong>Copyright &copy; <?php echo date("Y"); ?> <a href="https://adminlte.io"><?php echo get_title(); ?></a>.</strong> All rights reserved.
</footer>