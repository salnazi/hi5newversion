<?php
$file = file_get_contents("Notice.txt");
echo "<h5 style='color:grey;'>" . $file . "<h5>";
?>