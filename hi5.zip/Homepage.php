<!DOCTYPE html>
<html lang="en">
<?php include ("head.php"); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php
    //include ("top_nav.php");    
    include ("left_menu.php");   
    include ("content.php");    
    include ("footer.php");
?>
<aside class="control-sidebar control-sidebar-dark">
</aside>
</div>
<?php include ("footer_js.php"); ?>
</body>
</html>